export type HorzScalePriceItem = number;
